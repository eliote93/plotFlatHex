function PLOT_Seg(Pt01, Pt02, n, a)

plot([Pt01(1), Pt02(1)], [Pt01(2), Pt02(2)], a, 'LineWidth', n);

end