function PLOT_GapPins(pF2F, nPin, aiF2F, aoF2F, n, a)

aiPch = aiF2F / sqrt(3.);
aoPch = aoF2F / sqrt(3.);

Vtx = zeros(4, 7);

for iBndy = 1:7
    Ang = pi / 2. + (1 - iBndy) * pi / 3.;
    
    Vtx(1, iBndy) = aiPch * cos(Ang);
    Vtx(2, iBndy) = aiPch * sin(Ang);
    Vtx(3, iBndy) = aoPch * cos(Ang);
    Vtx(4, iBndy) = aoPch * sin(Ang);
end

for iBndy = 1:6
    PLOT_Seg(Vtx(1:2, iBndy), Vtx(1:2, iBndy+1), n, a);
    PLOT_Seg(Vtx(3:4, iBndy), Vtx(3:4, iBndy+1), n, a);
    PLOT_Seg(Vtx(1:2, iBndy), Vtx(3:4, iBndy),   n, a);
end

for iBndy = 1:7
    Ang = (2 - iBndy) * pi / 3.;
    
    Vtx(1, iBndy) = aiF2F * 0.5 * cos(Ang);
    Vtx(2, iBndy) = aiF2F * 0.5 * sin(Ang);
    Vtx(3, iBndy) = aoF2F * 0.5 * cos(Ang);
    Vtx(4, iBndy) = aoF2F * 0.5 * sin(Ang);
end

for iBndy = 1:6
    PLOT_Seg(Vtx(1:2, iBndy), Vtx(3:4, iBndy), n, a);
end

Pt(1) = aiF2F * 0.5 * cos(pi / 3.);
Pt(2) = aiF2F * 0.5 * sin(pi / 3.);
Pt(3) = aoF2F * 0.5 * cos(pi / 3.);
Pt(4) = aoF2F * 0.5 * sin(pi / 3.);

Vtx = zeros(8, nPin - 2);
Ang = -pi / 6;

for iDir = 1:nPin-2
    Vtx(1, iDir) = Pt(1) + pF2F * 0.5 * cos(Ang) * iDir;
    Vtx(2, iDir) = Pt(2) + pF2F * 0.5 * sin(Ang) * iDir;
    Vtx(3, iDir) = Pt(3) + pF2F * 0.5 * cos(Ang) * iDir;
    Vtx(4, iDir) = Pt(4) + pF2F * 0.5 * sin(Ang) * iDir;
    Vtx(5, iDir) = Pt(1) - pF2F * 0.5 * cos(Ang) * iDir;
    Vtx(6, iDir) = Pt(2) - pF2F * 0.5 * sin(Ang) * iDir;
    Vtx(7, iDir) = Pt(3) - pF2F * 0.5 * cos(Ang) * iDir;
    Vtx(8, iDir) = Pt(4) - pF2F * 0.5 * sin(Ang) * iDir;
end

Ang = -pi / 3.;

for iBndy = 1:6
    for iDir = 1:nPin-2
        PLOT_Seg(Vtx(1:2, iDir), Vtx(3:4, iDir), n, a);
        PLOT_Seg(Vtx(5:6, iDir), Vtx(7:8, iDir), n, a);
        
        Vtx(1:2, iDir) = RotPt(Vtx(1:2, iDir), Ang);
        Vtx(3:4, iDir) = RotPt(Vtx(3:4, iDir), Ang);
        Vtx(5:6, iDir) = RotPt(Vtx(5:6, iDir), Ang);
        Vtx(7:8, iDir) = RotPt(Vtx(7:8, iDir), Ang);
    end
end

end

