clc;
close all;
clear;
% ------------------------------------------------
%                  PLOT : Asy & mRay
% ------------------------------------------------
%aiF2F = 4.21881388702243;
%aoF2F = 4.61881388702243;
%nPin  = 3;
%pF2F  = 0.9134;

%aiF2F = 5.800869094655847;
%aoF2F = 6.000869094655847;
%nPin  = 4;
%pF2F  = 0.9134;

aiF2F = 20.28;
aoF2F = 20.6114;
nPin  = 9;
pF2F  = 1.35099962990372;

aoPch = aoF2F / sqrt(3.);

hold on;
axis equal;

xlim([-aoF2F*0.6 aoF2F*0.6]);
ylim([-aoPch*1.05  aoPch*1.05]);

%PLOT_InnPins(pF2F, nPin, 4, 'k');
PLOT_GapPins(pF2F, nPin, aiF2F, aoF2F, 4, 'k');
%PLOT_BndyPins(pF2F, nPin, aiF2F, 4, 'k');

nRng = 2;
sRng = [0.282842712474619 0.4];

%PLOT_RodMshs(pF2F, nPin, aiF2F, nRng, sRng, 1, 'k');
%PLOT_GapMshs(pF2F, nPin, aiF2F, aoF2F, 1, 'k');

Eqn01 = [sqrt(3.), 1., 0.];
Eqn02 = [0., 1., 0.];
Eqn03 = [-sqrt(3.), 1., 0.];
PLOT_Line(Eqn01, 2, 'b')
PLOT_Line(Eqn02, 2, 'b')
PLOT_Line(Eqn03, 2, 'b')

RayEqn = [0.06577408129844733, -1, 0.02510548523206779];
PLOT_Line(RayEqn, 2, 'r')

RayEqn = [2.02897380316118, -1, -7.87666666669895];
PLOT_Line(RayEqn, 2, 'r')

scatter(0.381692677973717, 0.)

SegPts(1,1)  = 0.03849011572528932;
SegPts(2,1)  = 2.64445116233405;
SegPts(1,2)  = -0.142336062;
SegPts(2,2)  = 2.530033291;
SegPts(1,3)  = -2.06E-02;
SegPts(2,3)  = 2.539317067;
SegPts(1,4)  = 0.00E+00;
SegPts(2,4)  = 2.540886958;
SegPts(1,5)  = 1.58E-02;
SegPts(2,5)  = 2.542090541;
SegPts(1,6)  = 0.155445962;
SegPts(2,6)  = 2.552740305;
SegPts(1,7)  = 0.192450579;
SegPts(2,7)  = 2.555562048;
SegPts(1,8)  = -0.263856771;
SegPts(2,8)  = 0.456386667;
SegPts(1,9)  = -0.263856771;
SegPts(2,9)  = 0.456386667;
SegPts(1,10) = -0.263205521;
SegPts(2,10) = 0.4567;
SegPts(1,11) = -0.263205521;
SegPts(2,11) = 0.4567;
SegPts(1,12) = 0.466322556;
SegPts(2,12) = 0.80769436;
SegPts(1,13) = 0.466322556;
SegPts(2,13) = 0.80769436;
SegPts(1,14) = 0.686027604;
SegPts(2,14) = 0.9134;
SegPts(1,15) = 0.686027604;
SegPts(2,15) = 0.9134;
SegPts(1,16) = 1.196501883;
SegPts(2,16) = 1.159002052;
SegPts(1,17) = 1.196501883;
SegPts(2,17) = 1.159002052;
SegPts(1,18) = 1.750062736;
SegPts(2,18) = 1.425334142;
SegPts(1,19) = 1.750062736;
SegPts(2,19) = 1.425334142;
SegPts(1,20) = 1.968244554;
SegPts(2,20) = 1.530306918;

%PLOT_Pts(SegPts, 1, 'b')

return